//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import PlaygroundSupport
import UIKit

PlaygroundPage.current.liveView = Main3Scene()

//#-end-hidden-code

/*:
 # Wrap it Together
Now that we have our mooncake dough and filling, we will be wrapping these two together! Join these components by drag and dropping your filling onto the dough.
 
 * Callout(Mid-Autumn Festival Greeting ✨): May the brightness of moon and stars fill your life with positivity and happiness. Wishing you a blissful and cheerful day.
*/
