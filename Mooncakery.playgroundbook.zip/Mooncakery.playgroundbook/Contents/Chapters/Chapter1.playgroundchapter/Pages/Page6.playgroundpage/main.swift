//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import PlaygroundSupport
import UIKit

PlaygroundPage.current.liveView = Main6Scene()

//#-end-hidden-code

/*:
 # Cherish and Celebrate 🎉 🌕
 Thanks for helping make this a good day! The mooncake you made looks delicious. Take some time to relax and moon-gaze at the bright and full moon. I hope you enjoyed making your mooncake 🥮 and wishing you the best of experiences to come!
*/
