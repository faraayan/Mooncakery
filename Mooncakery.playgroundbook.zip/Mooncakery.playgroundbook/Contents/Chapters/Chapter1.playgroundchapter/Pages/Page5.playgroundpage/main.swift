//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import PlaygroundSupport
import UIKit

PlaygroundPage.current.liveView = Main5Scene()

//#-end-hidden-code

/*:
 # Bake your Mooncake
Are you excited? We are almost done with making our mooncake! 🧑‍🍳 The final step is to bake the mooncake to acheive a golden to dark brown crust. Run the page to start the process.
 
 While your mooncake is baking, feel free to read a fun fact about mooncakes below!
 
 * Callout(The World's Largest Mooncake 🧐):
 Did you know? The Guinness World Record for the largest mooncake is awared to the Toronto Mid-Autumn Festival Committee in 2001. They baked a mooncake measuring 14.5 feet long and 9 feet wide! This took them 20 bakers and two whole days to bake the mooncake, weighing over 5,000 pounds when it was complete. That's crazy! 😆
*/

